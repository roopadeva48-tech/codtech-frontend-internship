import { ChatMessage, ChatUser } from '@/types/chat';

export const sampleMessages: ChatMessage[] = [
  {
    id: '1',
    text: 'Hey! How are you doing today?',
    sender: 'other',
    username: 'Alex',
    timestamp: new Date(Date.now() - 3600000), // 1 hour ago
  },
  {
    id: '2',
    text: 'I\'m doing great! Just working on some new features for our app. How about you?',
    sender: 'me',
    username: 'You',
    timestamp: new Date(Date.now() - 3540000), // 59 minutes ago
  },
  {
    id: '3',
    text: 'That sounds awesome! I\'d love to hear more about what you\'re building.',
    sender: 'other',
    username: 'Alex',
    timestamp: new Date(Date.now() - 3480000), // 58 minutes ago
  },
  {
    id: '4',
    text: 'It\'s a real-time chat application with a modern dark theme and neon accents. The UI is inspired by WhatsApp and Telegram but with a futuristic twist! 🚀',
    sender: 'me',
    username: 'You',
    timestamp: new Date(Date.now() - 3420000), // 57 minutes ago
  },
  {
    id: '5',
    text: 'Wow, that sounds incredible! I love the neon theme idea. Are you using WebSockets for the real-time functionality?',
    sender: 'other',
    username: 'Alex',
    timestamp: new Date(Date.now() - 3360000), // 56 minutes ago
  },
  {
    id: '6',
    text: 'Yes exactly! WebSockets make it feel instant and responsive. The chat bubbles have smooth animations and the whole experience feels really polished.',
    sender: 'me',
    username: 'You',
    timestamp: new Date(Date.now() - 3300000), // 55 minutes ago
  },
  {
    id: '7',
    text: 'I can\'t wait to try it out! When do you think it\'ll be ready for testing?',
    sender: 'other',
    username: 'Alex',
    timestamp: new Date(Date.now() - 300000), // 5 minutes ago
  },
];

export const sampleUsers: ChatUser[] = [
  {
    id: '1',
    username: 'Alex',
    isOnline: true,
  },
  {
    id: '2',
    username: 'You',
    isOnline: true,
  },
];