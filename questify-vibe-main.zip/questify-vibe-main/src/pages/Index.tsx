import { ChatContainer } from "@/components/ChatContainer";

const Index = () => {
  return (
    <div className="min-h-screen bg-background">
      <ChatContainer />
    </div>
  );
};

export default Index;
