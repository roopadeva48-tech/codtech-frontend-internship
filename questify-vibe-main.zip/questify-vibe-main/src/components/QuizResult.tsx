import { Button } from '@/components/ui/button';
import { Trophy, RotateCcw, Star } from 'lucide-react';

interface QuizResultProps {
  score: number;
  totalQuestions: number;
  onRestart: () => void;
}

export const QuizResult = ({ score, totalQuestions, onRestart }: QuizResultProps) => {
  const percentage = Math.round((score / totalQuestions) * 100);
  
  const getScoreLevel = () => {
    if (percentage >= 90) return 'excellent';
    if (percentage >= 70) return 'good';
    if (percentage >= 50) return 'average';
    return 'poor';
  };

  const getScoreMessage = () => {
    if (percentage >= 90) return 'Excellent work! You\'re a quiz master!';
    if (percentage >= 70) return 'Great job! You really know your stuff!';
    if (percentage >= 50) return 'Good effort! Keep practicing!';
    return 'Don\'t give up! Practice makes perfect!';
  };

  const getScoreIcon = () => {
    if (percentage >= 90) return <Trophy className="w-8 h-8" />;
    if (percentage >= 70) return <Star className="w-8 h-8" />;
    return <RotateCcw className="w-8 h-8" />;
  };

  return (
    <div className="w-full max-w-2xl mx-auto animate-bounce-in">
      <div className="result-card">
        {/* Score Circle */}
        <div className={`score-circle ${getScoreLevel()}`}>
          <div className="absolute inset-0 flex items-center justify-center">
            {getScoreIcon()}
          </div>
          <div className="relative z-10 flex flex-col items-center">
            <span className="text-4xl font-bold">{percentage}%</span>
          </div>
        </div>

        {/* Score Details */}
        <div className="space-y-4">
          <h2 className="text-3xl font-bold">Quiz Complete!</h2>
          <p className="text-xl text-muted-foreground">
            {getScoreMessage()}
          </p>
          
          <div className="flex items-center justify-center space-x-8 text-sm text-muted-foreground">
            <div className="text-center">
              <div className="text-2xl font-bold text-success">{score}</div>
              <div>Correct</div>
            </div>
            <div className="text-center">
              <div className="text-2xl font-bold text-error">{totalQuestions - score}</div>
              <div>Incorrect</div>
            </div>
            <div className="text-center">
              <div className="text-2xl font-bold text-primary">{totalQuestions}</div>
              <div>Total</div>
            </div>
          </div>
        </div>

        {/* Actions */}
        <div className="flex flex-col sm:flex-row gap-4 justify-center">
          <Button 
            onClick={onRestart}
            className="quiz-button primary"
          >
            <RotateCcw className="w-4 h-4 mr-2" />
            Try Again
          </Button>
          <Button 
            className="quiz-button secondary"
            onClick={() => window.location.reload()}
          >
            New Quiz
          </Button>
        </div>
      </div>
    </div>
  );
};