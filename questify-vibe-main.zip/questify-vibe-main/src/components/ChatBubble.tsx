import React from 'react';
import { ChatMessage } from '@/types/chat';

interface ChatBubbleProps {
  message: ChatMessage;
}

export const ChatBubble: React.FC<ChatBubbleProps> = ({ message }) => {
  const formatTime = (timestamp: Date) => {
    return timestamp.toLocaleTimeString([], { 
      hour: '2-digit', 
      minute: '2-digit' 
    });
  };

  return (
    <div className={`chat-message ${message.sender}`}>
      <div className="flex flex-col">
        <div className={`chat-bubble ${message.sender}`}>
          <p className="text-sm leading-relaxed">{message.text}</p>
        </div>
        <div className={`chat-meta ${message.sender}`}>
          <span>
            {message.sender === 'other' ? `${message.username} • ` : ''}
            {formatTime(message.timestamp)}
          </span>
        </div>
      </div>
    </div>
  );
};