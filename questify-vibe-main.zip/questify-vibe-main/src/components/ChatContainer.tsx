import React, { useState, useRef, useEffect } from 'react';
import { ChatMessage } from '@/types/chat';
import { sampleMessages } from '@/data/chatData';
import { ChatHeader } from './ChatHeader';
import { ChatMessages } from './ChatMessages';
import { ChatInput } from './ChatInput';

export const ChatContainer: React.FC = () => {
  const [messages, setMessages] = useState<ChatMessage[]>(sampleMessages);
  const [isTyping, setIsTyping] = useState(false);
  const messagesEndRef = useRef<HTMLDivElement>(null);

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  };

  useEffect(() => {
    scrollToBottom();
  }, [messages]);

  const handleSendMessage = (text: string) => {
    const newMessage: ChatMessage = {
      id: Date.now().toString(),
      text,
      sender: 'me',
      username: 'You',
      timestamp: new Date(),
    };

    setMessages(prev => [...prev, newMessage]);

    // Simulate typing response
    setIsTyping(true);
    setTimeout(() => {
      setIsTyping(false);
      const responseMessage: ChatMessage = {
        id: (Date.now() + 1).toString(),
        text: getRandomResponse(),
        sender: 'other',
        username: 'Alex',
        timestamp: new Date(),
      };
      setMessages(prev => [...prev, responseMessage]);
    }, 1000 + Math.random() * 2000);
  };

  const getRandomResponse = (): string => {
    const responses = [
      "That's really interesting! Tell me more about it.",
      "I totally agree with you on that point.",
      "Wow, I hadn't thought about it that way before!",
      "Thanks for sharing that with me.",
      "That sounds like a great idea!",
      "I'm really excited to see how this turns out.",
      "You always have such great insights!",
      "That's exactly what I was thinking too.",
      "This conversation is so engaging!",
      "I love how this chat app looks and feels!",
    ];
    return responses[Math.floor(Math.random() * responses.length)];
  };

  return (
    <div className="chat-container">
      <ChatHeader />
      <ChatMessages 
        messages={messages} 
        isTyping={isTyping}
        messagesEndRef={messagesEndRef}
      />
      <ChatInput onSendMessage={handleSendMessage} />
    </div>
  );
};