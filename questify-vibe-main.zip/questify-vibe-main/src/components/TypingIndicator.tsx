import React from 'react';

export const TypingIndicator: React.FC = () => {
  return (
    <div className="chat-message other">
      <div className="flex flex-col">
        <div className="chat-bubble other">
          <div className="typing-indicator">
            <div className="typing-dot"></div>
            <div className="typing-dot"></div>
            <div className="typing-dot"></div>
            <span className="ml-2 text-xs text-muted-foreground">typing...</span>
          </div>
        </div>
      </div>
    </div>
  );
};