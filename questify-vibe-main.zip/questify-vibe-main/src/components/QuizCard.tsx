import { useState, useEffect } from 'react';
import { Button } from '@/components/ui/button';
import { QuizQuestion } from '@/types/quiz';

interface QuizCardProps {
  question: QuizQuestion;
  currentQuestionIndex: number;
  totalQuestions: number;
  onAnswer: (selectedOption: number) => void;
  onNext: () => void;
  showResult: boolean;
  selectedOption: number | null;
  correctOption: number | null;
}

export const QuizCard = ({
  question,
  currentQuestionIndex,
  totalQuestions,
  onAnswer,
  onNext,
  showResult,
  selectedOption,
  correctOption
}: QuizCardProps) => {
  const [isAnswered, setIsAnswered] = useState(false);
  const progress = ((currentQuestionIndex + 1) / totalQuestions) * 100;

  useEffect(() => {
    setIsAnswered(false);
  }, [currentQuestionIndex]);

  const handleOptionClick = (optionIndex: number) => {
    if (isAnswered) return;
    
    setIsAnswered(true);
    onAnswer(optionIndex);
  };

  const getOptionClassName = (optionIndex: number) => {
    let baseClass = 'quiz-option';
    
    if (!isAnswered && selectedOption === optionIndex) {
      baseClass += ' selected';
    }
    
    if (showResult && isAnswered) {
      if (optionIndex === correctOption) {
        baseClass += ' correct';
      } else if (optionIndex === selectedOption && optionIndex !== correctOption) {
        baseClass += ' incorrect';
      }
    }
    
    return baseClass;
  };

  return (
    <div className="w-full max-w-2xl mx-auto animate-slide-up">
      <div className="quiz-card p-8 space-y-6">
        {/* Progress Header */}
        <div className="space-y-4">
          <div className="flex items-center justify-between text-sm text-muted-foreground">
            <span>Question {currentQuestionIndex + 1} of {totalQuestions}</span>
            <span>{Math.round(progress)}% Complete</span>
          </div>
          <div className="progress-bar">
            <div 
              className="progress-fill" 
              style={{ width: `${progress}%` }}
            />
          </div>
        </div>

        {/* Question */}
        <div className="space-y-6">
          <h2 className="text-2xl font-bold text-center leading-relaxed">
            {question.question}
          </h2>

          {/* Options */}
          <div className="space-y-3">
            {question.options.map((option, index) => (
              <button
                key={index}
                onClick={() => handleOptionClick(index)}
                className={getOptionClassName(index)}
                disabled={isAnswered}
              >
                <div className="flex items-center space-x-3">
                  <div className="w-8 h-8 rounded-full bg-secondary/50 flex items-center justify-center text-sm font-medium">
                    {String.fromCharCode(65 + index)}
                  </div>
                  <span className="text-left flex-1">{option}</span>
                </div>
              </button>
            ))}
          </div>

          {/* Next Button */}
          {showResult && (
            <div className="flex justify-center pt-4">
              <Button 
                onClick={onNext}
                className="quiz-button primary"
              >
                {currentQuestionIndex === totalQuestions - 1 ? 'View Results' : 'Next Question'}
              </Button>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};