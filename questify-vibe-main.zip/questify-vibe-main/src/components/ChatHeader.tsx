import React from 'react';

export const ChatHeader: React.FC = () => {
  return (
    <div className="chat-header">
      <div className="flex items-center justify-between">
        <div className="flex items-center space-x-3">
          <div className="chat-avatar">
            A
          </div>
          <div>
            <h2 className="font-semibold text-lg text-foreground">Alex Chen</h2>
            <div className="flex items-center space-x-2">
              <div className="online-indicator"></div>
              <span className="text-sm text-muted-foreground">Online</span>
            </div>
          </div>
        </div>
        <div className="flex items-center space-x-2 text-muted-foreground">
          <span className="text-sm">Real-time Chat</span>
        </div>
      </div>
    </div>
  );
};