export interface QuizQuestion {
  id: number;
  question: string;
  options: string[];
  correctAnswer: number;
}

export interface QuizState {
  currentQuestionIndex: number;
  selectedOption: number | null;
  score: number;
  isComplete: boolean;
  showResult: boolean;
}