export interface ChatMessage {
  id: string;
  text: string;
  sender: 'me' | 'other';
  username: string;
  timestamp: Date;
  avatar?: string;
}

export interface ChatUser {
  id: string;
  username: string;
  avatar?: string;
  isOnline: boolean;
}